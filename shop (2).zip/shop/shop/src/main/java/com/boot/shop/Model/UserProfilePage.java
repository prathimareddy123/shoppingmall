package com.boot.shop.Model;

public class UserProfilePage {

}
