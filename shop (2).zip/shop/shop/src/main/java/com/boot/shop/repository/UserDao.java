package com.boot.shop.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.boot.shop.Model.UserRegistrationModel;
@Repository
public interface UserDao extends JpaRepository<UserRegistrationModel, Integer> {
//
	@Query("SELECT u from UserRegistrationModel u where u.email=?1")
	public UserRegistrationModel findByEmail(String email);
	
	@Query("SELECT l from UserRegistrationModel l where l.email=?1 and l.password=?2")
	public UserRegistrationModel findByUser(String email,String password);
}
