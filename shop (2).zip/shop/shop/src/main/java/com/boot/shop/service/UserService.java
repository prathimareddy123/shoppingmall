package com.boot.shop.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.boot.shop.Model.UserRegistrationModel;
import com.boot.shop.repository.UserDao;

@Service
public class UserService {
	@Autowired
	UserDao userDao;

	public ModelAndView storeUser(UserRegistrationModel userRegisterModel,ModelAndView model) {
//		System.out.println((UserRegistrationModel)userDao.findByEmail(userRegisterModel.getEmail()));
		if(userDao.findByEmail(userRegisterModel.getEmail())==null) {
		userDao.save(userRegisterModel);
		model.setViewName("redirect:/login");
		return model;
		}
		else {
//			System.out.println(userDao.findByEmail(userRegisterModel.getEmail()));
			model.setViewName("redirect:/register");
			return model;
		}
	}

	public String dispalyStore(String email,String password) {
		if(userDao.findByUser(email,password)==null) {
			return "redirect:/login";
		}
		else {
			return "userdashboard";
		}
	}
	
	
}
